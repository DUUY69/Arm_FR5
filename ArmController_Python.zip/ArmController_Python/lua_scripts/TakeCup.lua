PTP(CupDow-safe-3,50,-1,0)
PTP(CupDow-safe-4,50,-1,0)
PTP(CupDow-safe-5,50,-1,0)
PTP(Rest_1,50,-1,0)
