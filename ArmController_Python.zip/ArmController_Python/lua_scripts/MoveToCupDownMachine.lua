PTP(Rest_1,100,-1,0)
PTP(CupDow-safe-1,100,-1,0)
PTP(CupDow-safe-2,100,-1,0)
PTP(CupDow-take,100,-1,0)