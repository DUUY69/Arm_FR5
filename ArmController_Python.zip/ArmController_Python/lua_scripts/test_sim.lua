print("hello from lua test")
